rm -rf apps/_default/databases
git archive --format=zip --output=CSE_183_Group_10_Project.zip main