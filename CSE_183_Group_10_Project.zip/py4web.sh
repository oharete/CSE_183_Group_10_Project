rm -rf apps/_default/databases
py4web run --errorlog=:stdout -L 20 apps
