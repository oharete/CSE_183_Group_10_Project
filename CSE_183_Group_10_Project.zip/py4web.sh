py4web run --errorlog=:stdout -L 20 apps
